#ifndef LAB_H
#define LAB_H

// Function declaration
void print_message(void);

// Function definition
#include <stdio.h>

void print_message(void) {
    printf("hello world i am lab03\n");
}

#endif /* LAB_H */
